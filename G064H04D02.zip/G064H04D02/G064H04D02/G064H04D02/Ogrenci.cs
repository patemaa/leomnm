﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G064H04D02
{
    internal class Ogrenci
    {
        public string Ad;
        public string Soyad;
        public int No;
        public string Sube;
        public bool MevcutMu;
    }
}
