﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G064H04D02
{
    internal class Araba
    {
        public string Marka;
        public string Renk;
        public int Yil;
        public double Fiyat;
    }
}
