﻿namespace G064H04D02
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
        private static void ArabaOrnekler()
        {
            //Örnek 1
            Araba araba1 = new Araba();
            araba1.Marka = "BMW";
            araba1.Renk = "Beyaz";
            araba1.Yil = 2021;
            araba1.Fiyat = 10_000_000;

            //Örnek 2
            Araba araba2 = new Araba()
            {
                Marka = "Mercedes",
                Fiyat = 7_000_000,
                Renk = "Siyah",
                Yil = 2020
            };
        }

        private static void OgrenciOrnekler()
        {
            Ogrenci o1 = new Ogrenci();
            o1.Ad = "Merve";
            o1.Soyad = "Soluk";
            o1.No = 1;
            o1.Sube = "A";

            Ogrenci o2 = new Ogrenci();
            o2.Ad = "Tansu";
            o2.Soyad = "Erol";
            o2.No = 2;
            o2.Sube = "B";

            Ogrenci o3 = new Ogrenci();
            o3.Ad = "Asım";
            o3.Soyad = "Almak";
            o3.No = 3;
            o3.Sube = "C";

            Ogrenci o4 = new Ogrenci();
            o4.Ad = "Tekin";
            o4.Soyad = "Kuvanç";
            o4.No = 4;
            o4.Sube = "C";

            List<Ogrenci> ogrenciler = new List<Ogrenci>();

            ogrenciler.Add(o1);
            ogrenciler.Add(o2);
            ogrenciler.Add(o3);
            ogrenciler.Add(o4);


            foreach (Ogrenci o in ogrenciler)
            {
                Console.WriteLine(o.Ad + " " + o.Soyad + " " + o.No + " " + o.Sube);
            }

        }

        private static void Listeler()
        {
            string[] isimlerDizisi = new string[3];
            isimlerDizisi[0] = "Kaan";
            isimlerDizisi[1] = "Cemile";
            isimlerDizisi[2] = "Tarık";

            List<string> isimlerListesi = new List<string>();

            isimlerListesi.Add("Almine");
            isimlerListesi.Add("Sema");
            isimlerListesi.Add("Asiye");
            isimlerListesi.Add("Saadet");
            isimlerListesi.Add("Deniz");
            isimlerListesi.Add("Yağmur");
            isimlerListesi.Add("Ergün");

            ListeYazdir(isimlerListesi);

            //Insert
            int index = 2;
            isimlerListesi.Insert(index, "Deniz");

            ListeYazdir(isimlerListesi);

            //Remove
            isimlerListesi.Remove("Yağmur");
            bool sildinMi = isimlerListesi.Remove("Cemile");

            ListeYazdir(isimlerListesi);

            //RemoveAt
            isimlerListesi.RemoveAt(index);
            ListeYazdir(isimlerListesi);

            //IndexOf
            int denizIndex = isimlerListesi.IndexOf("Deniz");
            Console.WriteLine(denizIndex);
            Console.WriteLine(isimlerListesi[denizIndex]);

            //Contains
            bool hasanVarMi = isimlerListesi.Contains("Hasan"); //false
            bool denizVarMi = isimlerListesi.Contains("Deniz"); //true

            foreach (string item in isimlerListesi)
            {
                Console.WriteLine(item);
            }
        }

        static void EskiListeYazdir(List<string> liste)
        {
            for (int i = 0; i < liste.Count; i++)
            {
                Console.Write(liste[i] + " ");
            }
            Console.WriteLine();
        }

        static void ListeYazdir(List<string> liste)
        {
            foreach (string item in liste)
            {
                Console.WriteLine(item);
            }
        }

        private static void HesapMakinesi()
        {
            //Günün Sorusu: 

            //Klavyeden bir işlem girelim.
            //Girdi örnek: 45 * 5 (Sayılar ve semboller arasında mutlaka 1 adet boşluk olmalı.)
            //Verilen bu işlemin sonucunu hesaplayıp ekrana yazdırın.
            //Çıktı örnek: 45 * 5 = 225 ( + - * /)
            //Bonus bilgi: Console.Clear() konsolu temizler

            string girdi = Console.ReadLine(); // "45 * 5"
            string[] girdiler = girdi.Split(" "); // ["45", "*", "5"]

            double s1 = double.Parse(girdiler[0]);
            double s2 = double.Parse(girdiler[2]);

            string islem = girdiler[1];

            double sonuc = 0;

            switch (islem)
            {
                case "+":
                    sonuc = s1 + s2;
                    break;

                case "-":
                    sonuc = s1 - s2;
                    break;

                case "*":
                    sonuc = s1 * s2;
                    break;

                case "/":
                    sonuc = s1 / s2;
                    break;

            }

            Console.Clear();
            Console.WriteLine(girdi + " = " + sonuc);
        }
    }
}