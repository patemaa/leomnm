﻿namespace SinemaUygulamasi
{
    internal class Program
    {
        static Sinema sinema;
        static void Main(string[] args)
        {
            Uygulama();
        }

        static void Uygulama()
        {
            Kurulum();
            Console.WriteLine();

            Menu();

            while (true)
            {
                string secim = SecimAl();
                switch (secim)
                {
                    case "1":
                    case "S":
                        BiletSat();
                        break;

                    case "2":
                    case "R":
                        BiletIade();
                        break;

                    case "3":
                    case "D":
                        DurumBilgisi();
                        break;

                    case "4":
                    case "X":
                        Cikis();
                        break;

                    default:
                        break;
                }
                Console.WriteLine();
            }
        }

        static void Kurulum()
        {

            Console.WriteLine("-------Butik Sinema Salonu-------");

            Console.Write("Film adı: ");
            string filmAdi = Console.ReadLine();

            Console.Write("Kapasite: ");
            int kapsite = int.Parse(Console.ReadLine());

            Console.Write("Tam Bilet Fiyatı: ");
            double tamBiletFiyati = double.Parse(Console.ReadLine());

            Console.Write("Yarım Bilet Fiyatı: ");
            double yarimBiletFiyati = double.Parse(Console.ReadLine());


            sinema = new Sinema(filmAdi, kapsite, tamBiletFiyati, yarimBiletFiyati);

        }


        static void Menu()
        {
            Console.WriteLine("1 - Bilet Sat(S)");
            Console.WriteLine("2 - Bilet İade(R)");
            Console.WriteLine("3 - Durum Bilgisi(D)");
            Console.WriteLine("4 - Çıkış(X)");
            Console.WriteLine();
        }

        static string SecimAl()
        {
            string olasiSecimler = "SRDX1234";
            int sayac = 0;

            while (true)
            {
                Console.Write("Seçiminiz: ");
                string girdi = Console.ReadLine().ToUpper();
                Console.WriteLine();

                if (olasiSecimler.Contains(girdi) && girdi.Length == 1)
                {
                    return girdi;
                }
                else
                {
                    sayac++;

                    if (sayac == 10)
                    {
                        Console.WriteLine("Üzgünüm sizi anlayamıyorum. Program sonlandırılıyor.");
                        Cikis();
                    }

                    Console.WriteLine("Hatalı giriş yapıldı.");
                }
            }
        }


        static void BiletSat()
        {
            Console.WriteLine("Bilet Sat:");

            Console.Write("Tam Bilet Adedi: ");
            int tam = int.Parse(Console.ReadLine());

            Console.Write("Yarım Bilet Adedi: ");
            int yarim = int.Parse(Console.ReadLine());

            sinema.BiletSatis(tam, yarim);

            Console.WriteLine("İşlem gerçekleştirildi.");

        }

        static void BiletIade()
        {
            Console.WriteLine("Bilet İade:");

            Console.Write("Tam Bilet Adedi: ");
            int tam = int.Parse(Console.ReadLine());

            Console.Write("Yarım Bilet Adedi: ");
            int yarim = int.Parse(Console.ReadLine());
            
            sinema.BiletIadesi(tam, yarim);

            Console.WriteLine("İşlem gerçekleştirildi.");


        }

        static void DurumBilgisi()
        {
            sinema.CiroHesapla();
            Console.WriteLine("Durum Bilgisi");
            Console.WriteLine("Film: " + sinema.FilmAdi);
            Console.WriteLine("Kapasite: " + sinema.Kapasite);
            Console.WriteLine("Tam Bilet Fiyatı : " + sinema.TamBiletFiyati);
            Console.WriteLine("Yarım Bilet Fiyatı : " + sinema.YarimBiletFiyati);
            Console.WriteLine("Toplam Tam Bilet Adedi: " + sinema.TamBiletAdet);
            Console.WriteLine("Toplam Yarım Bilet Adedi: " + sinema.YarimBiletAdet);
            Console.WriteLine("Ciro: " + sinema.Ciro);
            Console.WriteLine("Boş Koltuk Adedi: " + sinema.BosKoltukAdediGetir()) ;

        }
        static void Cikis()
        {
            Console.WriteLine("Uygulamadan çıkılyor...");
            Environment.Exit(0);

        }
    }
}