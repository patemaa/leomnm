﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SinemaUygulamasi
{
    internal class Sinema
    {
        public string FilmAdi;
        public int Kapasite;
        public double TamBiletFiyati;
        public double YarimBiletFiyati;

        public int TamBiletAdet;
        public int YarimBiletAdet;

        public double Ciro;

        public int BosKoltukAdediGetir()
        {
            return Kapasite - TamBiletAdet - YarimBiletAdet;
        }


        public void CiroHesapla()
        {
            Ciro = TamBiletFiyati * TamBiletAdet + YarimBiletFiyati * YarimBiletAdet;
        }

        public void BiletSatis(int tamAdet, int yarimAdet)
        {
            this.TamBiletAdet += tamAdet;
            this.YarimBiletAdet += yarimAdet;
        }

        public void BiletIadesi(int tamAdet, int yarimAdet)
        {
            this.TamBiletAdet -= tamAdet;
            this.YarimBiletAdet -= yarimAdet;
        }

        public Sinema(string filmAdi, int kapasite, double tamBiletFiyati, double yarimBiletFiyati)
        {
            FilmAdi = filmAdi;
            Kapasite = kapasite;
            TamBiletFiyati = tamBiletFiyati;
            YarimBiletFiyati = yarimBiletFiyati;
        }
    }
}
