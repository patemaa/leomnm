﻿namespace G064H06D02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DateTimeOrnekleri();
            TernaryOperator();
            StaticOrnekleri1();
            
            //Try -catch
            Console.WriteLine("Uygulama başladı");

            try
            {
                int sayi = int.Parse("beş"); //FormatException

                int[] dizi = new int[3];
                dizi[5] = 10; //IndexOutOfRangeException

                Ogrenci o = null;
                Console.WriteLine(o.Ad); //NullReferenceException

                throw new Exception("Kemalin özel hatası"); //Kemalin özel hatası


            }
            catch (FormatException e)
            {
                Console.WriteLine($"Format hatası oldu: {e.Message}");
            }
            catch (NullReferenceException e)
            {
                Console.WriteLine($"Olmayan bir nesneye erişmeye çalıştın {e.Message}");
            }
            catch (Exception e)
            {
                Console.WriteLine($"Başka bir hata oldu: {e.Message}");
            }

            try
            {
                DoSomething();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.WriteLine("Uygulama bitti");
        }

        static void DoSomething()
        {
            if (true)
            {
                throw new Exception("Hatalı bir durum oldu");

            }
        }

        private static void StaticOrnekleri1()
        {
            Okul okul1 = new Okul();
            okul1.OkulAdi = "Arda İlköğretim Okulu";


            Okul okul2 = new Okul();
            okul2.OkulAdi = "Burak Lisesi";

            okul1.ZilCal();
            okul2.ZilCal();

            Console.WriteLine(Okul.Tur);

            Okul.YonetmelikleriGetir();
            Console.WriteLine();
        }
        private static void TernaryOperator()
        {
            int sayi = 10;
            string sonuc;

            if (sayi > 0)
            {
                sonuc = "sayi pozitiftir";
            }
            else
            {
                sonuc = "sayi negatiftir";
            }

            sonuc = sayi > 0 ? "sayi pozitiftir" : "sayi negatiftir";

            Console.WriteLine(sonuc);

            //int sayi ve string sonuç değişkenlerini tanımlayın, sayı tek ise sonuç değişkeninde "sayı tektir" çift ise "sayı çiftir yazsın"
            sonuc = sayi % 2 == 0 ? "sayi çifttir" : "sayi tektir";


            if (sayi > 0)
            {
                sonuc = "sayi pozitiftir";
            }
            else if (sayi == 0)
            {
                sonuc = "sayi nötrdür";
            }
            else
            {
                sonuc = "sayi negatiftir";
            }

            sayi = 0;
            sonuc = sayi > 0 ? "sayi pozitiftir" : sayi == 0 ? "sayi nötrdür" : "sayi negatiftir";

            Console.WriteLine(sonuc);
            Console.WriteLine();
        }

        private static void DateTimeOrnekleri()
        {
            DateTime tarih = new DateTime(2023, 10, 1);
            DateTime tarih3 = new DateTime(2020, 02, 29);
            Console.WriteLine(tarih3);
            DateTime tarih2 = new DateTime(2023, 10, 1, 15, 7, 30, 23);

            tarih = DateTime.Now;
            tarih = DateTime.UtcNow;

            int yil = tarih.Year;
            int ay = tarih.Month;
            int gun = tarih.Day;
            int saat = tarih.Hour;
            int dakika = tarih.Minute;
            int saniye = tarih.Second;
            int salise = tarih.Millisecond;

            Console.WriteLine(saat);

            Console.WriteLine(tarih);

            DateTime tarih4 = tarih.AddHours(-1);
            tarih4 = tarih.AddMonths(5);
            Console.WriteLine(tarih4);

            TimeSpan sure = tarih4 - tarih;
            Console.WriteLine(sure.TotalDays);
            Console.WriteLine(tarih.DayOfWeek);
            Console.WriteLine(tarih.DayOfYear);

            if (tarih4 > tarih)
            {
                Console.WriteLine("asdfasd");
            }
            tarih4.CompareTo(tarih3);

            Console.WriteLine(tarih);

            Console.WriteLine("-------------------------");
            Console.WriteLine(tarih.ToShortDateString());
            Console.WriteLine(tarih.ToLongDateString());
            Console.WriteLine(tarih.ToLongTimeString());
            Console.WriteLine(tarih.ToShortTimeString());

            Console.WriteLine("-------------------------");

            Console.WriteLine(tarih.ToString("dd.MM.yyyy"));
            Console.WriteLine(tarih.ToString("yyyy.MM.dd"));
            Console.WriteLine(tarih.ToString("dd MMMM yyyy"));
            Console.WriteLine(tarih.ToString("dd.MM.yy"));
            Console.WriteLine(tarih.ToString("dd.MM.yy"));


            tarih.ToString("MM/dd/yy"); // 08/4/21
            tarih.ToString("MM/dd/yyyy");//08/04/2021
            tarih.ToString("dd/MM/yy");//04/08/21
            tarih.ToString("dd-MM-yy");//04-08-21
            tarih.ToString("ddd, dd MMM yyyy"); // Wed, 04 Aug 2021
            tarih.ToString("dddd, dd MMMM yy"); // Wednesday, 04 August 21
            tarih.ToString("dddd, dd MMMM yyyy HH:mm"); // Wednesday, 04 August 2021 23:58
            tarih.ToString("MM/dd/yy HH:mm"); // 08/04/21 23:58
            tarih.ToString("MM/dd/yyyy hh:mm tt"); // 08/04/2021 11:58 PM
            tarih.ToString("MM/dd/yyyy H:mm t"); // Wed, 04 Aug 2021 P
            tarih.ToString("MM/dd/yyyy H:mm:ss"); // 08/04/2021 23:58:30
            tarih.ToString("MMM dd"); // Aug 04
            tarih.ToString("MM-dd-yyyTHH:mm:ss.fff"); // 08-04-2021T23:58:30.999
            tarih.ToString("MM-dd-yyy g"); // 08-04-2021 A.D.
            tarih.ToString("HH:mm"); // 23:58
            tarih.ToString("hh:mm tt"); // 11:58 PM
            tarih.ToString("HH:mm:ss"); // 23:58:30
            tarih.ToString("'Full DateTime:' MM-dd-yyyTHH:mm:ss"); // Full DateTime: 08-04-2021T23:58:30

            DateTime tarih5 = DateTime.Parse("11.12.2021");
            Console.WriteLine();
        }
    }
}