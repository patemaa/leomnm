﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G064H06D02
{
    internal class Ogrenci
    {
        public string Ad { get; set; }

        public void DersCalis()
        {

        }
    }
}
