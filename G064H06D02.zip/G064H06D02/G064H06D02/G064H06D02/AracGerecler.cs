﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G064H06D02
{
    internal static class AracGerecler
    {
        public static string AracGerecAdi = "Araçlar";

        public static string IlkHarfiBuyut(string s)
        {
            return s.Substring(0, 1).ToUpper() + s.Substring(1).ToLower();
        }

        public static int SayiAl()
        {
            while (true)
            {
                Console.Write("Sayi girin: ");
                string giris = Console.ReadLine();
                bool success = int.TryParse(giris, out int sayi);

                if(success)
                {
                    return sayi;
                }
                else
                {
                    Console.WriteLine("Hatali");
                }
            }
        }
    }
}
