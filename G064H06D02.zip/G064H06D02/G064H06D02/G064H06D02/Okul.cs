﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G064H06D02
{
    internal class Okul
    {
        public static string Tur = "Eğitim Kurumu";

        public string OkulAdi { get; set; }
        public void ZilCal()
        {
            Console.WriteLine($"{OkulAdi} okulunun zili çalıyor.");
        }

        public static void YonetmelikleriGetir()
        {
            Console.WriteLine("Yönetmelikler: ");
            Console.WriteLine("1: asjhaskjh");
            Console.WriteLine("2: afdasfadsf");
        }

    }
}
