﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqCalismalari
{
    class Uygulama
    {
        public void Calistir()
        {
            List<Ogrenci> ogrenciler = new List<Ogrenci>();

            Ogrenci o1 = new Ogrenci(1, "Naz", SUBE.A, 10, 20, CINSIYET.Kiz, ALAN.Sayisal);

            ogrenciler.Add(o1);
            ogrenciler.Add(new Ogrenci(2, "Elif", SUBE.A, 45, 25, CINSIYET.Kiz, ALAN.Sozel));
            ogrenciler.Add(new Ogrenci(3, "Busra", SUBE.B, 56, 30, CINSIYET.Kiz, ALAN.EsitAgirlik));
            ogrenciler.Add(new Ogrenci(4, "Hakan", SUBE.B, 67, 35, CINSIYET.Erkek, ALAN.Sozel));
            ogrenciler.Add(new Ogrenci(5, "Ahmet", SUBE.B, 89, 40, CINSIYET.Erkek, ALAN.Sayisal));
            ogrenciler.Add(new Ogrenci(6, "Mehmet", SUBE.C, 23, 45, CINSIYET.Erkek, ALAN.EsitAgirlik));
            ogrenciler.Add(new Ogrenci(7, "Beril", SUBE.C, 74, 50, CINSIYET.Kiz, ALAN.Sozel));
            ogrenciler.Add(new Ogrenci(8, "Nurgül", SUBE.D, 56, 55, CINSIYET.Kiz, ALAN.EsitAgirlik));
            ogrenciler.Add(new Ogrenci(9, "Burak", SUBE.D, 63, 21, CINSIYET.Erkek, ALAN.Sayisal));
            ogrenciler.Add(new Ogrenci(10, "Eren", SUBE.D, 11, 33, CINSIYET.Erkek, ALAN.Sayisal));
            ogrenciler.Add(new Ogrenci(11, "Sarp", SUBE.D, 65, 23, CINSIYET.Erkek, ALAN.EsitAgirlik));
            ogrenciler.Add(new Ogrenci(12, "Osman", SUBE.A, 77, 18, CINSIYET.Erkek, ALAN.Sozel));
            ogrenciler.Add(new Ogrenci(13, "Halit", SUBE.B, 55, 35, CINSIYET.Erkek, ALAN.Sayisal));
            ogrenciler.Add(new Ogrenci(14, "Berke", SUBE.C, 35, 43, CINSIYET.Erkek, ALAN.Sozel));
            ogrenciler.Add(new Ogrenci(15, "Aslı", SUBE.A, 43, 26, CINSIYET.Kiz, ALAN.Sayisal));
            ogrenciler.Add(new Ogrenci(16, "Selim", SUBE.D, 71, 19, CINSIYET.Erkek, ALAN.Sozel));
            ogrenciler.Add(new Ogrenci(17, "Melek", SUBE.D, 62, 24, CINSIYET.Kiz, ALAN.EsitAgirlik));
            ogrenciler.Add(new Ogrenci(18, "Derya", SUBE.C, 75, 31, CINSIYET.Kiz, ALAN.EsitAgirlik));
            ogrenciler.Add(new Ogrenci(19, "Melis", SUBE.B, 40, 42, CINSIYET.Kiz, ALAN.Sayisal));
            ogrenciler.Add(new Ogrenci(20, "Melda", SUBE.B, 90, 22, CINSIYET.Kiz, ALAN.EsitAgirlik));
            ogrenciler.Add(new Ogrenci(21, "Onur", SUBE.C, 68, 17, CINSIYET.Erkek, ALAN.Sozel));
            ogrenciler.Add(new Ogrenci(22, "Fatih", SUBE.D, 73, 27, CINSIYET.Erkek, ALAN.Sayisal));
            ogrenciler.Add(new Ogrenci(23, "Salih", SUBE.D, 81, 39, CINSIYET.Erkek, ALAN.EsitAgirlik));
            ogrenciler.Add(new Ogrenci(24, "Çağan", SUBE.A, 87, 38, CINSIYET.Erkek, ALAN.Sozel));
            ogrenciler.Add(new Ogrenci(25, "Emre", SUBE.B, 75, 25, CINSIYET.Erkek, ALAN.EsitAgirlik));
            ogrenciler.Add(new Ogrenci(26, "Emre", SUBE.C, 79, 20, CINSIYET.Erkek, ALAN.Sayisal));
            ogrenciler.Add(new Ogrenci(27, "Kemal", SUBE.C, 55, 21, CINSIYET.Erkek, ALAN.Sayisal));
            ogrenciler.Add(new Ogrenci(28, "Kemal", SUBE.D, 66, 22, CINSIYET.Erkek, ALAN.Sayisal));
            ogrenciler.Add(new Ogrenci(29, "Kemal", SUBE.A, 77, 23, CINSIYET.Erkek, ALAN.Sayisal));

            List<Ogrenci> yeniListe = new List<Ogrenci>();


            //foreach (Ogrenci o in ogrenciler)
            //{
            //    if(o.Not > 50 o.Yas > 20)
            //    {
            //        yeniListe.Add(o);
            //    }
            //}

            //Where ----------------------------------------------


            //Notu 50'den ve yaşı 20'den büyük olan öğrencileri listeledik
            yeniListe = ogrenciler.Where(o => o.Not > 50 && o.Yas > 20).ToList();

            //Alanı sayısal olan 20 yaş üstü öğrencileri listeleyin
            yeniListe = ogrenciler.Where(o => o.Alan == ALAN.Sayisal && o.Yas > 20).ToList();

            //Alanı eşit ağırlık olmayan B şubesindeki öğrencileri listeleyin.
            yeniListe = ogrenciler.Where(o => o.Alan != ALAN.EsitAgirlik && o.Subesi == SUBE.B).ToList();

            //Notu 30'dan yüksek olan Sözel öğrencileri listeleyin
            yeniListe = ogrenciler.Where(o => o.Not > 30 && o.Alan == ALAN.Sozel).ToList();


            //OrderBy(), OrderByDescending----------------------------------------------

            //OrderBy küçükten büyüğe, A'dan Z'ye sıralama yapar
            yeniListe = ogrenciler.OrderBy(o => o.Not).ToList();

            //OrderByDescending büyükten küçüğe, Z'den A'ya sıralama yapar
            yeniListe = ogrenciler.OrderByDescending(o => o.Ad).ToList();

            //Where() ve OrderBy birlikte kullanılabilir
            yeniListe = ogrenciler.Where(o => o.Alan == ALAN.EsitAgirlik).OrderBy(o => o.Not).ToList();

            //Notu 75'den küçük ve 50'den büyük olan öğrencileri subelerine göre A>Z'ye sıralayalım
            yeniListe = ogrenciler.Where(o => o.Not < 75 && o.Not > 50).OrderBy(s => s.Subesi).ToList();

            //Eşitağırlık bölümünde okuyan erkek öğrencileri isimlerine göre A>Z'ye sıralayın
            yeniListe = ogrenciler.Where(o => o.Alan == ALAN.EsitAgirlik && o.Cinsiyet == CINSIYET.Erkek).OrderBy(o => o.Ad).ToList();

            
            
            //ThenBy(), ThenByDescending() ----------------------------------------------

            //Sayısal bölümünde okuyan erkek öğrencileri önce isimlerine göre A>Z'ye sonra notlarına göre büyükten küçüğe sıralayın
            yeniListe = ogrenciler.Where(o => o.Alan == ALAN.Sayisal && o.Cinsiyet == CINSIYET.Erkek).OrderBy(o => o.Ad).ThenByDescending(o => o.Not).ToList();

            //Aynı isimdeki öğrencileri kendi içinde büyükten küçüğe yaşına göre sıralayın.
            yeniListe = ogrenciler.OrderBy(a => a.Ad).ThenByDescending(o => o.Yas).ToList();


            //Take() ----------------------------------------------
            
            //Okuldaki en yaşlı 3 öğrenciyi listeleyin
            yeniListe = ogrenciler.OrderByDescending(a => a.Yas).Take(3).ToList();

            //Sözel bölümde okuyan en yüksek notlu 5 öğrenciyi listeleyin.
            yeniListe = ogrenciler.Where(o => o.Alan == ALAN.Sozel).OrderByDescending(o => o.Not).Take(5).ToList();

            //Hatalı
            //yeniListe = ogrenciler.Take(5).Where(a => a.Alan == ALAN.Sozel).OrderByDescending(a => a.Not).ToList();

            //Hatalı
            //yeniListe = ogrenciler.OrderByDescending(a => a.Not).Take(5).Where(a => a.Alan == ALAN.Sozel).ToList();

            
            //FirstOrDefault() ----------------------------------------------
           
            Ogrenci o;

            yeniListe = ogrenciler.Where(o => o.No == 15).ToList();
            o = yeniListe[0];

            o = ogrenciler.Where(o => o.No == 15).FirstOrDefault();

            o = ogrenciler.FirstOrDefault(o => o.No == 15);

            //En genç öğrenciyi çekin
            o = ogrenciler.OrderBy(o => o.Yas).FirstOrDefault();

            if (o != null)
            {
                //Console.WriteLine(o.Ad);

            }
            yeniListe = ogrenciler.OrderBy(o => o.Yas).ToList();
            //ListeYazdir(yeniListe);


            //Average() ----------------------------------------------
            
            //B şubesindeki öğrencilerin yaş ortalaması
            double ortalama = ogrenciler.Where(o => o.Subesi == SUBE.B).Average(o => o.Yas);

            Console.WriteLine($"B şubesindeki öğrencilerin yaş ortalaması: {ortalama:N2}");


            //Sum(), Min(), Max() ----------------------------------------------
            
            //Sözel bölümünde okuyan öğrencilerin yaşlarının toplamı nedir?
            int toplam = ogrenciler.Where(o => o.Alan == ALAN.Sozel).Sum(o => o.Yas);
            Console.WriteLine($"Sözel bölümünde okuyan öğrencilerin yaşlarının toplamı: {toplam}");

            //Okuldaki en büyük öğrenci numarası nedir
            int max = ogrenciler.Max(o => o.No);
            Console.WriteLine($"Okuldaki en büyük öğrenci numarası: {max}");

            //Okuldaki en küçük öğrenci numarası nedir
            int min = ogrenciler.Min(o => o.No);
            Console.WriteLine($"Okuldaki en küçük öğrenci numarası: {min}");

            min = ogrenciler.OrderBy(o => o.No).FirstOrDefault().No;
            Console.WriteLine($"Okuldaki en küçük öğrenci numarası: {min}");
        }

        public void ListeYazdir(List<Ogrenci> liste)
        {
            Console.WriteLine("No".PadRight(5) + "Ad".PadRight(10) + "Yas".ToString().PadRight(5) + "Cinsiyet".ToString().PadRight(10)
                + "Sube".PadRight(5) + "Not".PadRight(5) + "Alan");
            Console.WriteLine("".PadRight(52, '-'));

            foreach (Ogrenci item in liste)
            {
                Console.WriteLine(item.No.ToString().PadRight(5) + item.Ad.PadRight(10) + item.Yas.ToString().PadRight(5) + item.Cinsiyet.ToString().PadRight(10)
                    + item.Subesi.ToString().PadRight(5) + item.Not.ToString().PadRight(5) + item.Alan);
            }
        }
    }
}
