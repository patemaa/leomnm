﻿using System;

namespace LinqCalismalari
{
    class Program
    {
        static void Main(string[] args)
        {

            //Uygulama u = new Uygulama();
            //u.Calistir();

            new Uygulama().Calistir();

        }
    }
}
