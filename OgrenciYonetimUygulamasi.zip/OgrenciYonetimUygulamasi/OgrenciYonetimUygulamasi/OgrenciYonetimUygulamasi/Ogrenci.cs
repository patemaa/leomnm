﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OgrenciYonetimUygulamasi
{
    internal class Ogrenci
    {
        public int No;
        public string Ad;
        public string Soyad;
        public string Sube;

        public int DogumYili;
        public int Yas;

        public int MatematikNotu;
        public int FizikNotu;
        public int KimyaNotu;

        public Ogrenci(int no, string ad, string soyad, string sube, int dogumYili, int matematikNotu, int fizikNotu, int kimyaNotu)
        {
            this.No = no;
            this.Ad = ad;
            this.Soyad = soyad;
            this.Sube = sube;
            this.DogumYili = dogumYili;
            this.MatematikNotu = matematikNotu;
            this.FizikNotu = fizikNotu;
            this.KimyaNotu = kimyaNotu;
        }

        public Ogrenci()
        {
        }

        public double OrtalamaGetir()
        {
            double ortalama = (double)(MatematikNotu + FizikNotu + KimyaNotu) / 3;

            return ortalama;
        }

        public void YasHesapla()
        {
            Yas = 2023 - DogumYili;
        }

        public void YasYazdir()
        {
            int yas = 2023 - this.DogumYili;
            Console.WriteLine(Ad + ": Yaşım: " + yas);
        }

        public void SelamVer()
        {
            Console.WriteLine("Selamlar! ben " + Ad);
        }

    }
}
