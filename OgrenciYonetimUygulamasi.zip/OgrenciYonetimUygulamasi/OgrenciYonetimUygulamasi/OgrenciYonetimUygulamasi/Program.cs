﻿namespace OgrenciYonetimUygulamasi
{
    internal class Program
    {
        static List<Ogrenci> ogrenciler = new List<Ogrenci>();
        static bool devamMi = true;

        static void Main(string[] args)
        {
            Uygulama();
            //Test();
        }

        static void Test()
        {
            Ogrenci o1 = new Ogrenci()
            {
                No = 1,
                Ad = "Kemal",
                Soyad = "Uysal",
                Sube = "A",
                DogumYili = 2000,
                MatematikNotu = 75,
                FizikNotu = 50,
                KimyaNotu = 80

            };

            Ogrenci o2 = new Ogrenci()
            {
                No = 2,
                Ad = "Yağmur",
                Soyad = "Kepcan",
                Sube = "C",
                DogumYili = 1998,
                MatematikNotu = 40,
                FizikNotu = 90,
                KimyaNotu = 70
            };

            Ogrenci o3 = new Ogrenci()
            {
                No = 3,
                Ad = "Halil",
                Soyad = "Özçakmak",
                Sube = "B",
                DogumYili = 2003,
                MatematikNotu = 60,
                FizikNotu = 65,
                //KimyaNotu = 85
            };

            //o1.YasYazdir();
            //o2.YasYazdir();

            //Console.WriteLine(o1.Yas);
            //o1.YasHesapla();
            //Console.WriteLine(o1.Yas);

            //o3.YasHesapla();
            //Console.WriteLine(o3.Yas);

            //ogrenciler.Add(o1);
            //ogrenciler.Add(o2);
            //ogrenciler.Add(o3);

            //foreach (var o in ogrenciler)
            //{
            //    o.SelamVer();
            //}


            //Console.WriteLine(o1.OrtalamaGetir());
            //Console.WriteLine(o2.OrtalamaGetir());
            //Console.WriteLine(o3.OrtalamaGetir());


            //Ogrenci o4 = new Ogrenci(5, "Akif", "Karaman", "C", 2000, 50, 64, 84);

            //Console.WriteLine(o4.Ad);
        }

        static void Uygulama()
        {
            SahteVeriEkle();
            Menu();

            while (devamMi)
            {
                Console.WriteLine();

                string secim = SecimAl();

                switch (secim)
                {
                    case "1":
                    case "E":
                        OgrenciEkle();
                        break;

                    case "2":
                    case "L":
                        OgrenciListele();
                        break;

                    case "3":
                    case "S":
                        OgrenciSil();
                        break;

                    case "4":
                    case "X":
                        Cikis();
                        break;
                }
            }


        }

        static string SecimAl()
        {
            string olasiSecimler = "ELSX1234";
            int sayac = 0;

            while (true)
            {
                Console.Write("Seçiminiz: ");
                string girdi = Console.ReadLine().ToUpper();

                if (olasiSecimler.Contains(girdi) && girdi.Length == 1)
                {
                    return girdi;
                }
                else
                {
                    sayac++;

                    if (sayac == 10)
                    {
                        Console.WriteLine("Üzgünüm sizi anlayamıyorum. Program sonlandırılıyor.");
                        Cikis();
                    }

                    Console.WriteLine("Hatalı giriş yapıldı.");
                }
            }

        }

        static void Cikis()
        {
            Console.WriteLine("Uygulamadan çıkılyor...");

            Environment.Exit(0);

        }

        static void Menu()
        {
            Console.WriteLine("Öğrenci Yönetim Uygulaması");
            Console.WriteLine("1 - Öğrenci Ekle (E)");
            Console.WriteLine("2 - Öğrenci Listele (L)");
            Console.WriteLine("3 - Öğrenci Sil (S)");
            Console.WriteLine("4 - Çıkış (X)");
            Console.WriteLine();
        }

        static void OgrenciEkle()
        {
            Console.WriteLine("1 - Öğrenci Ekle----------");

            int sira = ogrenciler.Count + 1;
            Console.WriteLine(sira + ". Öğrencinin");

            Ogrenci o = new Ogrenci();

            int no;
            do
            {
                Console.Write("No: ");
                no = int.Parse(Console.ReadLine());

            } while (OgrenciVarMi(no));


            o.No = no;


            Console.Write("Adı: ");
            o.Ad = IlkHarfiBuyut(Console.ReadLine());

            Console.Write("Soyadı: ");
            o.Soyad = IlkHarfiBuyut(Console.ReadLine());

            Console.Write("Şubesi: ");
            o.Sube = IlkHarfiBuyut(Console.ReadLine());

            Console.WriteLine();
            Console.Write("Öğrenciyi kaydetmek istediğinize emin misiniz? (E / H): ");
            string secim = Console.ReadLine().ToUpper();

            Console.WriteLine();

            if (secim == "E")
            {
                ogrenciler.Add(o);
                Console.WriteLine("Öğrenci eklendi.");
            }
            else
            {
                Console.WriteLine("Öğrenci eklenmedi.");
            }

        }
        static bool OgrenciVarMi(int no)
        {
            foreach (Ogrenci o in ogrenciler)
            {
                if (o.No == no)
                {
                    Console.WriteLine("Bu numarada bir öğrenci var!");
                    return true;
                }
            }

            return false;
        }

        static string IlkHarfiBuyut(string s)
        {
            return s.Substring(0, 1).ToUpper() + s.Substring(1).ToLower();
        }

        static void OgrenciListele()
        {
            Console.WriteLine("2 - Öğrenci Listele---------- -");

            if (ogrenciler.Count == 0)
            {
                Console.WriteLine("Gösterilecek öğrenci yok");
                return;
            }

            Console.WriteLine("");
            Console.WriteLine("Şube".PadRight(10) + "No".PadRight(8) + "Ad Soyad");
            Console.WriteLine("----------------------------------");

            foreach (Ogrenci o in ogrenciler)
            {
                Console.WriteLine(o.Sube.PadRight(10) + o.No.ToString().PadRight(8) + o.Ad + " " + o.Soyad);
            }

        }

        static void OgrenciSil()
        {
            Console.WriteLine("3 - Öğrenci Sil----------");

            if (ogrenciler.Count == 0)
            {
                Console.WriteLine("Listede silinecek öğrenci yok.");

                //metottan çıksın
                return;
            }



            Console.WriteLine("Silmek istediğiniz öğrencinin");
            Console.Write("No: ");
            int no = int.Parse(Console.ReadLine());


            Ogrenci silinecekOgrenci = null;

            foreach (Ogrenci ogrenci in ogrenciler)
            {
                if (ogrenci.No == no)
                {
                    silinecekOgrenci = ogrenci;
                }
            }

            if (silinecekOgrenci != null)
            {

                Console.WriteLine("Adı: " + silinecekOgrenci.Ad);
                Console.WriteLine("Soyadı: " + silinecekOgrenci.Soyad);
                Console.WriteLine("Şubesi: " + silinecekOgrenci.Sube);

                Console.Write("Öğrenciyi silmek istediğinize emin misiniz? (E / H): ");
                string secim = Console.ReadLine().ToUpper();

                if (secim == "E")
                {
                    ogrenciler.Remove(silinecekOgrenci);
                    Console.WriteLine("Öğrenci silindi.");
                }
                else
                {
                    Console.WriteLine("Öğrenci silinmedi.");
                }
            }

            else
            {
                Console.WriteLine("Böyle bir öğrenci bulunamadı.");
            }
        }
        static void SahteVeriEkle()
        {
            Ogrenci o1 = new Ogrenci()
            {
                No = 1,
                Ad = "Deniz",
                Soyad = "Akbaş",
                Sube = "A",
                DogumYili = 1998,
                MatematikNotu = 40,
                FizikNotu = 90,
                KimyaNotu = 70
            };

            Ogrenci o2 = new Ogrenci()
            {
                No = 2,
                Ad = "Yıldız",
                Soyad = "Para",
                Sube = "C",
                DogumYili = 2002,
                MatematikNotu = 31,
                FizikNotu = 87,
                KimyaNotu = 65
            };

            Ogrenci o3 = new Ogrenci()
            {
                No = 3,
                Ad = "Ülkü",
                Soyad = "Karataş",
                Sube = "B",
                DogumYili = 2001,
                MatematikNotu = 54,
                FizikNotu = 64,
                KimyaNotu = 94
            };

            ogrenciler.Add(o1);
            ogrenciler.Add(o2);
            ogrenciler.Add(o3);
        }
    }
}