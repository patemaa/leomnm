﻿
using Newtonsoft.Json;
using System.Net.Http.Json;

namespace _1_JsonExamples
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
           await ReadJsonFromHttp();
        }

        private static async Task ReadJsonFromHttp()
        {
            //internetteki bir sunucudaki users.json dosyasını okuyacağız
            //sunucudaki json dosyasını okumak için:

            HttpClient client = new HttpClient()
            {
                BaseAddress = new Uri("https://jsonplaceholder.typicode.com")
            };


            //var response = await client.GetAsync("users/1");
            //string userStr = await response.Content.ReadAsStringAsync();
            //User user2 = JsonConvert.DeserializeObject<User>(userStr);

            User user = await client.GetFromJsonAsync<User>("users/1");

            Console.WriteLine($"Id: {user.Id} Name: {user.Name} Username: {user.Username} Email: {user.Email} ");

            Console.WriteLine("----------------------------");

            List<User> users = await client.GetFromJsonAsync<List<User>>("users");
            foreach (var item in users)
            {
                Console.WriteLine($"Id: {item.Id} Name: {item.Name} Username: {item.Username} Email: {item.Email} ");

            }

        }

        private static void ReadJsonFromFile()
        {
            //bilgisayarımdaki ogrenciler.json dosyasını okuyacağız

            //bilgisayardaki json dosyasını okumak için:
            string fileName = "ogrenciler.json";
            string path = Path.Combine("C:\\Users\\alike\\Desktop\\data", fileName);
            StreamReader r = new StreamReader(path);
            string json = r.ReadToEnd();




            //Console.WriteLine(json);

            //bu dosyayı c# objelerine çevireceğiz

            //json formatındaki string'i C# objesine "Deserialize" ermek için:
            List<Ogrenci> ogrenciler = JsonConvert.DeserializeObject<List<Ogrenci>>(json);



            //erkana yazdırmak için:
            foreach (var ogrenci in ogrenciler)
            {
                Console.WriteLine($"Ad: {ogrenci.ad}");
                Console.WriteLine($"Soyad: {ogrenci.soyad}");
                Console.WriteLine($"LinkedIn adresi: {ogrenci.linkedinAdresi}");
                Console.WriteLine($"Sınıf: {ogrenci.sinifAdi}");
                Console.WriteLine($"İl: {ogrenci.adres.il}");
                Console.WriteLine($"İlçe: {ogrenci.adres.ilçe}");

                Console.Write("Aldığı dersler: ");
                foreach (var ders in ogrenci.alinanDersler)
                {
                    Console.Write($"{ders} ");
                }
                Console.WriteLine();
                Console.WriteLine("--------------------------------");
                Console.WriteLine();

            }
        }
    }
}