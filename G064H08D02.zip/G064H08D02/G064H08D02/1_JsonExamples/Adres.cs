﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_JsonExamples
{
    internal class Adres
    {
        public string il { get; set; }
        public string ilçe { get; set; }
    }
}
