﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_JsonExamples
{
    internal class Ogrenci
    {
        public string ad { get; set; }
        public string soyad { get; set; }
        public string linkedinAdresi { get; set; }
        public string sinifAdi { get; set; }
        public Adres adres { get; set; }
        public List<string> alinanDersler { get; set; }
    }
}
